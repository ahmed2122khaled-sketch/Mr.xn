#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/gradle/wrapper/gradle-wrapper.jar"
BUILD="$ROOT/tools/gradle-bootstrap/classes"
rm -rf "$BUILD"
mkdir -p "$BUILD"
javac --release 17 -d "$BUILD" "$ROOT/tools/gradle-bootstrap/GradleBootstrap.java"
TMP="$ROOT/tools/gradle-bootstrap/manifest.mf"
printf '%s\n' 'Manifest-Version: 1.0' 'Main-Class: GradleBootstrap' > "$TMP"
jar --create --file "$OUT" --manifest "$TMP" -C "$BUILD" .
sha256sum "$OUT" | tee "$ROOT/gradle/wrapper/gradle-wrapper-bootstrap.sha256"
rm -rf "$BUILD"
