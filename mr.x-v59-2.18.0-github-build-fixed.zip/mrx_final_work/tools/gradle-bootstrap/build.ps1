$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Source = Join-Path $Root 'tools\gradle-bootstrap\GradleBootstrap.java'
$Build = Join-Path $Root 'tools\gradle-bootstrap\classes'
$Out = Join-Path $Root 'gradle\wrapper\gradle-wrapper.jar'
if (Test-Path $Build) { Remove-Item $Build -Recurse -Force }
New-Item -ItemType Directory -Force $Build | Out-Null
& javac --release 17 -d $Build $Source
$Manifest = Join-Path $Root 'tools\gradle-bootstrap\manifest.mf'
Set-Content -Path $Manifest -Value @('Manifest-Version: 1.0','Main-Class: GradleBootstrap') -NoNewline
& jar --create --file $Out --manifest $Manifest -C $Build .
(Get-FileHash $Out -Algorithm SHA256).Hash.ToLowerInvariant() | ForEach-Object { "$_  gradle-wrapper.jar" } | Set-Content (Join-Path $Root 'gradle\wrapper\gradle-wrapper-bootstrap.sha256')
Remove-Item $Build -Recurse -Force
