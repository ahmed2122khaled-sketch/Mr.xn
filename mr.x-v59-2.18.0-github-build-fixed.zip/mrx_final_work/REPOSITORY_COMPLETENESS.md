# Repository completeness

Checked 2026-09-24.

## Included

- Android source, resources, manifest, ProGuard rules, Gradle build files.
- Gradle Wrapper scripts and pinned Gradle 9.7.1 distribution/checksum.
- Deterministic wrapper-JAR fetch + checksum verification for environments that do not already have the binary.
- Supabase initial schema migration: profiles, posts, stories, follows, likes, comments, conversations, conversation members, messages, notifications.
- Auth-user → profile trigger.
- RLS policies and conversation membership helper.
- Counter and notification triggers.
- Direct-conversation RPC.
- Media Storage bucket and user-scoped write/delete policies.
- Existing high-load indexes migration.
- Snyk IaC workflow and Android build verification workflow.
- Secret-safe `.gitignore` and Supabase deployment guide.

## Deliberately not committed

- `supabase.properties` because it contains project configuration/credentials.
- Android SDK and Gradle distributions because they are machine/toolchain dependencies.
- The Gradle Wrapper JAR is fetched from the official Gradle release and checksum-verified instead of embedding a fabricated binary.
